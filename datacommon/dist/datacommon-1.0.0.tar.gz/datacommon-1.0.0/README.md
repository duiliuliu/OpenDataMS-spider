# OpenDataMS-spider

> 开放数据管理系统-数据采集模块

[设计文档](https://github.com/duiliuliu/OpenDataMS-docs)
[前端](https://github.com/duiliuliu/OpenDataMS-front)
[后端](https://github.com/duiliuliu/OpenDataMS-back)

爬虫使用爬虫库 [sspider](https://github.com/duiliuliu/simple-spiders)进行抓取数据

`pip install sspider`
